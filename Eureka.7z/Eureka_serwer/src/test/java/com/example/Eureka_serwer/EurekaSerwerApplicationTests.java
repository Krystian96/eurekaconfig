package com.example.Eureka_serwer;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class EurekaSerwerApplicationTests {

	@Test
	void contextLoads() {
	}

}
